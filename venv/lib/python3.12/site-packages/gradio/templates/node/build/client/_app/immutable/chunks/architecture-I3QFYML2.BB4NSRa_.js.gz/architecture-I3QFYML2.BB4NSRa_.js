import { A, e } from "./mermaid-parser.core.BKWREEBS.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
