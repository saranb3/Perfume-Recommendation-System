import { G, f } from "./mermaid-parser.core.BKWREEBS.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
