import { a1, a0 } from "../chunks/2.B3Zq3zkk.js";
export {
  a1 as component,
  a0 as universal
};
