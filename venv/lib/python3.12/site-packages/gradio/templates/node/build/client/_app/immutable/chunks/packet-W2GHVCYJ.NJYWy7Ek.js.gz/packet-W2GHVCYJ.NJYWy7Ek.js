import { P, a } from "./mermaid-parser.core.BKWREEBS.js";
export {
  P as PacketModule,
  a as createPacketServices
};
