import { I, c } from "./mermaid-parser.core.BKWREEBS.js";
export {
  I as InfoModule,
  c as createInfoServices
};
